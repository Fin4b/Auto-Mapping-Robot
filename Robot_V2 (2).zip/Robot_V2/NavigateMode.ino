void navigateLoop()
{
  
}